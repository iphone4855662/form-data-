//
//  ViewController.m
//  PictureHead
//
//  Created by 涂婉丽 on 15/12/8.
//  Copyright (c) 2015年 涂婉丽. All rights reserved.
//

#import "ViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "AFNetworking.h"
#import "SVProgressHUD.h"
@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>
{

    UIImagePickerController *pickerController;
    AFHTTPRequestOperationManager *manager;
}
@property(nonatomic,copy)NSString *imagePath;
@property(nonatomic,copy)NSString *imageName;
@property(nonatomic,strong)NSData *imageData;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //初始化头像控件
    [self initHeadIcon];
    //初始化pickController
    [self createData];
}
- (void)initHeadIcon
{

    self.view.backgroundColor = [UIColor lightGrayColor];
    self.headIcon.layer.cornerRadius = self.headIcon.frame.size.height/2;
    self.headIcon.clipsToBounds = YES;
    self.headIcon.layer.borderColor = [UIColor whiteColor].CGColor;
    self.headIcon.layer.borderWidth = 3;
}
- (void)createData
{
    //初始化pickerController
    pickerController = [[UIImagePickerController alloc]init];
    pickerController.view.backgroundColor = [UIColor orangeColor];
    pickerController.delegate = self;
    pickerController.allowsEditing = YES;
}

- (IBAction)changeIconAction:(UITapGestureRecognizer *)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"选择头像" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照",@"相册",@"图库", nil];
    [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {//相机
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
        {
            NSLog(@"支持相机");
            [self makePhoto];
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请在设置-->隐私-->相机，中开启本应用的相机访问权限！！" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"我知道了", nil];
            [alert show];
        }
    }else if (buttonIndex == 1){//相片
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
        {
            NSLog(@"支持相册");
            [self choosePicture];
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请在设置-->隐私-->照片，中开启本应用的相机访问权限！！" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"我知道了", nil];
            [alert show];
        }
    }else if (buttonIndex == 2){//图册
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum])
        {
            NSLog(@"支持图库");
            [self pictureLibrary];
//            [self presentViewController:picker animated:YES completion:nil];
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请在设置-->隐私-->照片，中开启本应用的相机访问权限！！" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"我知道了", nil];
            [alert show];
        }
    }else if (buttonIndex == 3){
        
    }

}
//跳转到imagePicker里
- (void)makePhoto
{
    pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:pickerController animated:YES completion:nil];
}
//跳转到相册
- (void)choosePicture
{
    pickerController.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    [self presentViewController:pickerController animated:YES completion:nil];
}
//跳转图库
- (void)pictureLibrary
{
    pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:pickerController animated:YES completion:nil];
}
//用户取消退出picker时候调用
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"%@",picker);
    [pickerController dismissViewControllerAnimated:YES completion:^{
        
    }];
}
//用户选中图片之后的回调
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    NSLog(@"%s,info == %@",__func__,info);
    NSString *imageURL = [NSString  stringWithFormat:@"%@",[info  objectForKey:@"UIImagePickerControllerImageURL"]];
//    NSArray *imagePathArray = [imageURL componentsSeparatedByString:@"/"];
    self.imageName =  [imageURL substringFromIndex:7];
    NSLog(@"self.imageName  ===== %@",self.imageName);
    
//    NSLog(@"self.imageName  ===== %@",self.imageName);

    UIImage *userImage = [self fixOrientation:[info objectForKey:@"UIImagePickerControllerOriginalImage"]];
    
    userImage = [self scaleImage:userImage toScale:0.1];
    
    [pickerController dismissViewControllerAnimated:YES completion:^{

    }];
    [self.headIcon setImage:userImage];
    self.headIcon.contentMode = UIViewContentModeScaleAspectFill;
    self.headIcon.clipsToBounds = YES;
    //照片上传
    [self upDateHeadIcon:userImage];
}
#pragma mark--图片格式转换//照片获取本地路径转换
-(NSString *)getImagePath:(UIImage *)Image {
    
    NSString * filePath = nil;
    self.imageData = nil;
    
//    if (UIImagePNGRepresentation(Image) == nil) {
//        data = UIImageJPEGRepresentation(Image, 0.5);
//    } else {
        self.imageData = UIImagePNGRepresentation(Image);
//    }
    
    //图片保存的路径
    //这里将图片放在沙盒的documents文件夹中
    NSString * DocumentsPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    //文件管理器
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    //把刚刚图片转换的data对象拷贝至沙盒中
    [fileManager createDirectoryAtPath:DocumentsPath withIntermediateDirectories:YES attributes:nil error:nil];
    NSString * ImagePath = [[NSString alloc]initWithFormat:@"/theFirstImage.png"];
    [fileManager createFileAtPath:[DocumentsPath stringByAppendingString:ImagePath] contents:self.imageData attributes:nil];
    
    //得到选择后沙盒中图片的完整路径
    filePath = [[NSString alloc]initWithFormat:@"%@%@",DocumentsPath,ImagePath];
    
    return filePath;
}
- (void)upDateHeadIcon:(UIImage *)photo
{
   
   
    self.imageName =  [self getImagePath:photo];
    NSLog(@"self.imageName  ===== %@",self.imageName);
    NSString *kHttpRequestHeadContentTypeValueMultipart = @"multipart/form-data; boundary= fgejigjiejigest";
    NSString *kHttpRequestHeadContentTypeKey = @"Content-Type";
    NSString *kHttpRequestHeadBoundaryValue = @"fgejigjiejigest";
    NSString *kHttpRequestContentDisposition = @"Content-Disposition: form-data";
    
    NSString *urlString = @"http://192.168.0.109:8762/file/upLoadImages";
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration];
    
    NSMutableURLRequest *mutableRequest = [NSMutableURLRequest requestWithURL:url];
    mutableRequest.HTTPMethod = @"POST";
    [mutableRequest addValue:kHttpRequestHeadContentTypeValueMultipart forHTTPHeaderField:kHttpRequestHeadContentTypeKey];
    
    NSString *body = [NSString stringWithFormat:@"--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"Identification", @"Identification对应的字段值"];
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"appuserIdStr",@"appuserIdStr对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"arrivalTime",@"arrivalTime对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"billCommodityStr",@"billCommodityStr对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"billTime",@"billTime对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"day",@"day对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"freight",@"freight对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"isStages",@"isStages对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"billByStagesStr",@"billByStagesStr对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"logisticsNum",@"logisticsNum对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"mobilePhone",@"mobilePhone对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"remarks",@"remarks对应的字段值"]];
    
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"\r\n\r\n%@", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition, @"state",@"state对应的字段值"]];
    //这里是要上传图片了，注意上传图片你的格式
//
//
    body = [body stringByAppendingString:[NSString stringWithFormat:@"\r\n--%@\r\n%@; name=\"%@\"; filename=\"%@\"\r\n;Content-Type=image/png\r\n\r\n", kHttpRequestHeadBoundaryValue, kHttpRequestContentDisposition,@"file",   self.imageName]];
    
    NSMutableData *data = [NSMutableData data];
    [data appendData:[body dataUsingEncoding:NSUTF8StringEncoding]];
//     NSData *imageData = UIImagePNGRepresentation(photo);
//    NSString *imagePath = [[NSBundle mainBundle]pathForResource:self.imagePath ofType:nil];
//    NSData *imageData = [[NSData alloc]initWithContentsOfFile:imagePath];
    [data appendData:self.imageData];
    [data appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", kHttpRequestHeadBoundaryValue] dataUsingEncoding:NSUTF8StringEncoding]];
    mutableRequest.HTTPBody = data;
    [mutableRequest setValue:[NSString stringWithFormat:@"%lu", (unsigned long)data.length] forHTTPHeaderField:@"Content-Length"];
    NSURLSessionUploadTask *task = [session uploadTaskWithRequest:mutableRequest fromData:nil completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (!error) {
            NSError *errorError;
            id dataObject = [NSJSONSerialization JSONObjectWithData:data options:0 error:&errorError];
            
            if ([dataObject isKindOfClass:[NSDictionary class]]) {
                NSDictionary *dict = (NSDictionary *)dataObject;
                NSLog(@"我的dict = %@",dict);
                NSInteger code = [[dict valueForKey:@"code"] integerValue];
                NSDictionary *resultDict = [dict valueForKey:@"result"];
                
                if (code == 200 && resultDict.count) {
                    [SVProgressHUD showSuccessWithStatus:@"成功"];
                    NSLog(@"%@",dataObject);
                    //进入相应的界面处理中
                    dispatch_async(dispatch_get_main_queue(), ^{
                        //回调或者说是通知主线程刷新
                    });
                    
                }else{
                    [SVProgressHUD showErrorWithStatus:@"失败"];
                }
            }else{
                [SVProgressHUD showSuccessWithStatus:@"失败"];
            }
        }else{
            NSLog(@"%@",error);
            [SVProgressHUD showErrorWithStatus:@"由于网络原因发送失败,请调整网络后重试"];
        }
        //NSLog(@"%@",response);
    }];
    [task resume];
    
    
    
    
    
}
-(NSData *)getDataWithString:(NSString *)string{
    
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    
    return data;
    
}

//保存照片到沙盒路径(保存)
- (void)saveImage:(UIImage *)image name:(NSString *)iconName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    //写入文件
    NSString *icomImage = iconName;
    NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png", icomImage]];
    // 保存文件的名称
    //    [[self getDataByImage:image] writeToFile:filePath atomically:YES];
    [UIImagePNGRepresentation(image)writeToFile: filePath  atomically:YES];
}
//缩放图片
- (UIImage *)scaleImage:(UIImage *)image toScale:(float)scaleSize
{
    UIGraphicsBeginImageContext(CGSizeMake(image.size.width*scaleSize,image.size.height*scaleSize));
    [image drawInRect:CGRectMake(0, 0, image.size.width * scaleSize, image.size.height *scaleSize)];
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSLog(@"%@",NSStringFromCGSize(scaledImage.size));
    return scaledImage;
}
//修正照片方向(手机转90度方向拍照)
- (UIImage *)fixOrientation:(UIImage *)aImage {
    
    // No-op if the orientation is already correct
    if (aImage.imageOrientation == UIImageOrientationUp)
        return aImage;
    
    // We need to calculate the proper transformation to make the image upright.
    // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (aImage.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, aImage.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, aImage.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        default:
            break;
    }
    
    switch (aImage.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        default:
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, aImage.size.width, aImage.size.height,
                                             CGImageGetBitsPerComponent(aImage.CGImage), 0,
                                             CGImageGetColorSpace(aImage.CGImage),
                                             CGImageGetBitmapInfo(aImage.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (aImage.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.height,aImage.size.width), aImage.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.width,aImage.size.height), aImage.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
